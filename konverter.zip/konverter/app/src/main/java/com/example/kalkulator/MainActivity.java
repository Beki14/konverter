package com.example.kalkulator;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.kalkulator.R;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAmount;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextAmount = findViewById(R.id.editTextAmount);
        textViewResult = findViewById(R.id.textViewResult);
    }

    private void convertCurrency(double conversionRate, String currencyCode) {
        String amountString = editTextAmount.getText().toString();

        if (!amountString.isEmpty()) {
            double amount = Double.parseDouble(amountString);
            double convertedAmount = amount * conversionRate;

            String resultMessage = String.format("%.2f EUR = %.2f %s", amount, convertedAmount, currencyCode);
            textViewResult.setText(resultMessage);
        } else {
            textViewResult.setText("Unesite iznos.");
        }
    }

    public void convertToHRK(View view) {
        convertCurrency(7.5345, "HRK");
    }

    public void convertToUSD(View view) {
        convertCurrency(1.13, "USD");
    }

    public void convertToJPY(View view) {
        convertCurrency(160, "JPY");
    }

    public void convertToGBP(View view) {
        convertCurrency(0.85, "GBP");
    }

    public void convertToSEK(View view) {
        convertCurrency(11.3, "SEK");
    }

}
